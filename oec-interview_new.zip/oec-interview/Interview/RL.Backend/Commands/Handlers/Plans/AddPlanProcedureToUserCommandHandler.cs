﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using RL.Backend.Exceptions;
using RL.Backend.Models;
using RL.Data;
using RL.Data.DataModels;


namespace RL.Backend.Commands.Handlers.Plans;

public class AddPlanProcedureToUserCommandHandler : IRequestHandler<AddPlanProcedureToUserCommand, ApiResponse<Unit>>
{
    private readonly RLContext _context;

    public AddPlanProcedureToUserCommandHandler(RLContext context)
    {
        _context = context;
    }

    public async Task<ApiResponse<Unit>> Handle(AddPlanProcedureToUserCommand request, CancellationToken cancellationToken)
    {
        try
        {
            //Validate request
            if (request.PlanId < 1)
                return ApiResponse<Unit>.Fail(new BadRequestException("Invalid PlanId"));
            if (request.ProcedureId < 1)
                return ApiResponse<Unit>.Fail(new BadRequestException("Invalid ProcedureId"));

            if (request.UserId < 1)
                return ApiResponse<Unit>.Fail(new BadRequestException("Invalid UserId"));

            var plan = await _context.Plans
                .Include(p => p.PlanProcedures)
                .FirstOrDefaultAsync(p => p.PlanId == request.PlanId);

            //var procedure = await _context.Procedures.FirstOrDefaultAsync(p => p.ProcedureId == request.ProcedureId);

            var procedure = await _context.Procedures
                .Include(p => p.PlanProceduresUser)
                .FirstOrDefaultAsync(p => p.ProcedureId == request.ProcedureId);

            var user = await _context.PlanProceduresUsers.FirstOrDefaultAsync(p =>p.PlanId == request.PlanId && p.ProcedureId==request.ProcedureId && p.UserId == request.UserId);


            if (plan is null)
                return ApiResponse<Unit>.Fail(new NotFoundException($"PlanId: {request.PlanId} not found"));
            if (procedure is null)
                return ApiResponse<Unit>.Fail(new NotFoundException($"ProcedureId: {request.ProcedureId} not found"));


            //Already has the PlanProceduresUser, so just succeed
            if (procedure.PlanProceduresUser.Any(p => p.PlanId == request.PlanId && p.ProcedureId == request.ProcedureId && p.UserId == request.UserId))
                return ApiResponse<Unit>.Succeed(new Unit());

            procedure.PlanProceduresUser.Add(new PlanProceduresUser
            {
                ProcedureId = procedure.ProcedureId,
                PlanId = plan.PlanId,
                UserId = request.UserId
            });


            await _context.SaveChangesAsync();

            return ApiResponse<Unit>.Succeed(new Unit());
        }
        catch (Exception e)
        {
            return ApiResponse<Unit>.Fail(e);
        }
    }
}