import React, { useEffect,useState } from "react";
import ReactSelect from "react-select";


const PlanProcedureItem = ({ procedure, users, planProcedures ,handleAddPlanProcedureToUser}) => {
    //const [selectedUsers, setSelectedUsers] = useState([]);
  
    

    // const handleAddPlanProcedureToUser = async (e,procedure) => {
    //     setSelectedUsers(e);
    //     const hasProcedureInPlan = planProcedures.some((p) => p.procedureId === procedure.procedureId);
    //     if (hasProcedureInPlan) return;
    
    //     await addProcedureToPlan(id, procedure.procedureId);
    //     setPlanProcedures((prevState) => {
    //       return [
    //         ...prevState,
    //         {
    //           planId: id,
    //           procedureId: procedure.procedureId,
    //           procedure: {
    //             procedureId: procedure.procedureId,
    //             procedureTitle: procedure.procedureTitle,
    //             selectedUsers:selectedUsers,
    //           },
    //         },
    //       ];
    //     });
    //   };

   

    const handleAssignUserToProcedure = (e) => {      
        //setSelectedUsers(e);
        // TODO: Remove console.log and add missing logic
        console.log(e);
        //console.log(selectedUsers);
        
    };

    return (
        <div className="py-2">
            <div>
                {procedure.procedureTitle}
            </div>

            <ReactSelect
                className="mt-2"
                placeholder="Select User to Assign"
                isMulti={true}
                options={users}
                value={planProcedures.find(
                    (p) => p.procedureId === procedure.procedureId
                ) ? procedure.selectedUsers: []}               
                onChange={(e) => handleAddPlanProcedureToUser(e,procedure,planProcedures)}
            />
        </div>
    );
};

export default PlanProcedureItem;
